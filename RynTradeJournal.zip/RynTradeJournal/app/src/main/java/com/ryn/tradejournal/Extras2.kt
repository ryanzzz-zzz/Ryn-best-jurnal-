package com.ryn.tradejournal

import android.util.Xml
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.time.DayOfWeek
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.TemporalAdjusters
import kotlin.math.abs

private fun conn(u: String) = (URL(u).openConnection() as HttpURLConnection).apply { connectTimeout = 8000; readTimeout = 8000 }
private val KEY_REL = Regex("Employment Situation|Consumer Price|Gross Domestic|Personal Income|Producer Price|Retail|Industrial Production|Unemployment Insurance Weekly|Job Openings|Durable|Consumer Sentiment|Housing Starts|Advance", RegexOption.IGNORE_CASE)

/** Official US release dates (no times/forecast/actual). Requires FRED_API_KEY. */
suspend fun fredReleases(from: LocalDate, to: LocalDate): Result<List<Pair<String, String>>> = withContext(Dispatchers.IO) {
    runCatching {
        if (BuildConfig.FRED_API_KEY.isBlank()) error("no key")
        val c = conn("https://api.stlouisfed.org/fred/releases/dates?api_key=${BuildConfig.FRED_API_KEY}&file_type=json&realtime_start=$from&realtime_end=$to&include_release_dates_with_no_data=true&sort_order=asc&limit=1000")
        val a = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("release_dates")
        (0 until a.length()).map { a.getJSONObject(it).let { o -> o.getString("date") to o.getString("release_name") } }
    }
}

/** Official Federal Reserve press-release RSS (no key needed). */
suspend fun fedNews(): Result<List<NewsItem>> = withContext(Dispatchers.IO) {
    runCatching {
        val xp = Xml.newPullParser(); xp.setInput(conn("https://www.federalreserve.gov/feeds/press_all.xml").inputStream, null)
        val out = mutableListOf<NewsItem>()
        var tag = ""; var title = ""; var date = ""; var cat = ""; var inItem = false
        var e = xp.eventType
        while (e != XmlPullParser.END_DOCUMENT) {
            when (e) {
                XmlPullParser.START_TAG -> { tag = xp.name; if (tag == "item") { inItem = true; title = ""; date = ""; cat = "" } }
                XmlPullParser.TEXT -> if (inItem) when (tag) { "title" -> title += xp.text; "pubDate" -> date += xp.text; "category" -> cat += xp.text }
                XmlPullParser.END_TAG -> {
                    if (xp.name == "item") {
                        val hi = Regex("FOMC|Federal Open Market|monetary policy|interest rate|discount rate", RegexOption.IGNORE_CASE).containsMatchIn(title)
                        out += NewsItem(title.trim(), "Federal Reserve", date.trim(), cat.trim().ifBlank { "Press release" }, if (hi) "HIGH" else "—")
                        inItem = false
                    }
                    tag = ""
                }
            }
            e = xp.next()
        }
        out.take(30)
    }
}

@Composable fun NewsScreen() {
    val p = prefs(LocalContext.current)
    var items by remember { mutableStateOf(listOf<NewsItem>()) }
    var status by remember { mutableStateOf("Loading…") }
    LaunchedEffect(Unit) {
        val r = fedNews()
        if (r.isSuccess) {
            items = r.getOrThrow(); status = "Source: Federal Reserve press releases (official RSS)."
            p.edit().putString("fednews", items.joinToString("\n") { "${it.headline}\t${it.published}\t${it.category}\t${it.importance}" }).apply()
        } else {
            items = (p.getString("fednews", "") ?: "").lines().filter { it.isNotBlank() }.mapNotNull { l -> l.split("\t").takeIf { it.size == 4 }?.let { NewsItem(it[0], "Federal Reserve", it[1], it[2], it[3]) } }
            status = if (items.isEmpty()) "News data unavailable." else "Offline — showing cached data"
        }
    }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("US market intelligence", fontSize = 24.sp, fontWeight = FontWeight.Bold); Text(status, color = Amber, fontSize = 12.sp) }
        item { Text("Only Fed releases are connected. Add a NewsProvider for CPI/NFP/Treasury/geopolitics coverage. Importance is keyword-based.", fontSize = 12.sp, color = Color.Gray) }
        items(items) { n ->
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Text(n.headline, fontWeight = FontWeight.SemiBold)
                    Text("${n.source} · ${n.published} · ${n.category} · Impact ${n.importance}", fontSize = 11.sp, color = Color.Gray)
                    if (n.importance == "HIGH") Text("Why it matters: rate expectations can influence USD and yields, and Gold may react depending on what markets had priced in. Not a guarantee of direction.", fontSize = 12.sp, color = Color.LightGray)
                }
            }
        }
    }
}

@Composable fun CalendarScreen() {
    val p = prefs(LocalContext.current)
    var range by rememberSaveable { mutableIntStateOf(0) }
    var keyOnly by rememberSaveable { mutableStateOf(true) }
    var rows by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var status by remember { mutableStateOf("Loading…") }
    LaunchedEffect(range) {
        val today = LocalDate.now(ZoneId.of("Asia/Jakarta"))
        val nextMon = today.with(TemporalAdjusters.next(DayOfWeek.MONDAY))
        val (from, to) = when (range) { 0 -> today to today; 1 -> today.plusDays(1) to today.plusDays(1)
            2 -> today to today.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY)); else -> nextMon to nextMon.plusDays(6) }
        val ck = "cal_${from}_$to"
        val r = fredReleases(from, to)
        if (r.isSuccess) {
            rows = r.getOrThrow(); p.edit().putString(ck, rows.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
            status = "US release dates from FRED. Time, forecast and actual are not provided (--)."
        } else {
            rows = (p.getString(ck, "") ?: "").lines().filter { it.contains("\t") }.map { it.split("\t").let { s -> s[0] to s[1] } }
            status = if (BuildConfig.FRED_API_KEY.isBlank()) "Connect a data provider: add FRED_API_KEY to local.properties."
            else if (rows.isEmpty()) "Calendar data unavailable." else "Offline — showing cached data"
        }
    }
    val shown = rows.filter { !keyOnly || KEY_REL.containsMatchIn(it.second) }.take(80)
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Economic calendar", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScrollCompat(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Today", "Tomorrow", "This week", "Next week").forEachIndexed { i, s -> FilterChip(range == i, { range = i }, { Text(s) }) }
        }
        FilterChip(keyOnly, { keyOnly = !keyOnly }, { Text("Key US releases only") })
        Text(status, color = Amber, fontSize = 12.sp)
        if (shown.isEmpty()) Text("No events in this range.", color = Color.Gray)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(shown) { (d, n) -> Column { Text(n, fontWeight = FontWeight.Medium); Text("$d · United States · Forecast -- · Actual --", fontSize = 11.sp, color = Color.Gray) } }
        }
    }
}

private fun Modifier.horizontalScrollCompat(): Modifier = this

private fun Double.z() = if (isNaN()) 0.0 else this
private fun sess(ms: Long): String {
    val h = Instant.ofEpochMilli(ms).atZone(ZoneId.of("Asia/Jakarta")).hour
    return if (h in 7..13) "Asia" else if (h in 14..18) "London" else if (h >= 19 || h < 4) "New York" else "Off-hours"
}

fun LazyListScope.extraItems(t: List<Trade>) {
    val z = ZoneId.of("Asia/Jakarta"); val fmt = DateTimeFormatter.ofPattern("dd MMM")
    val days = t.groupBy { Instant.ofEpochMilli(it.date).atZone(z).toLocalDate() }.mapValues { it.value.sumOf { x -> x.pnl } }.toSortedMap()
    val best = days.maxByOrNull { it.value }; val worst = days.minByOrNull { it.value }
    item { Pair2("Avg win" to f(t.filter { it.pnl > 0 }.map { it.pnl }.average().z()), "Avg loss" to f(t.filter { it.pnl < 0 }.map { it.pnl }.average().z()), ca = Green, cb = Red) }
    if (best != null && worst != null) item { Pair2("Best day (${fmt.format(best.key)})" to f(best.value), "Worst day (${fmt.format(worst.key)})" to f(worst.value), ca = Green, cb = Red) }
    item {
        Text("Daily P&L (last 14 days)", color = Color.Gray)
        val v = days.values.toList().takeLast(14)
        Canvas(Modifier.fillMaxWidth().height(120.dp)) {
            val m = v.maxOf { abs(it) }.let { if (it == 0.0) 1.0 else it }; val w = size.width / v.size; val mid = size.height / 2
            v.forEachIndexed { i, d ->
                val h = (abs(d) / m * mid).toFloat()
                drawRect(if (d >= 0) Green else Red, Offset(i * w + w * 0.15f, if (d >= 0) mid - h else mid), Size(w * 0.7f, maxOf(1f, h)))
            }
            drawLine(Color.Gray, Offset(0f, mid), Offset(size.width, mid), 1f)
        }
    }
    item { Text("Win rate by session (by entry time, WIB, approx.)", color = Color.Gray) }
    items(t.groupBy { sess(it.date) }.toList().sortedBy { it.first }) { (s, l) ->
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(s); Text("${f(l.count { it.pnl > 0 } * 100.0 / l.size)}% (${l.size})") }
    }
    item { Text("Plan discipline", color = Color.Gray) }
    items(listOf(true, false)) { fp ->
        val l = t.filter { it.followedPlan == fp }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(if (fp) "Followed plan (${l.size})" else "Broke plan (${l.size})"); Text(f(l.sumOf { it.pnl }), color = pnlColor(l.sumOf { it.pnl }))
        }
    }
}
