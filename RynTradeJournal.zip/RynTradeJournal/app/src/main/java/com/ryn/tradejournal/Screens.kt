package com.ryn.tradejournal

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.abs
import java.text.SimpleDateFormat
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Date
import java.util.Locale

val Green = Color(0xFF22C55E); val Red = Color(0xFFEF4444)
val Cyan = Color(0xFF22D3EE); val Amber = Color(0xFFF59E0B)

fun f(d: Double) = "%.2f".format(d)
fun String.num() = toDoubleOrNull() ?: 0.0
fun pnlColor(d: Double) = if (d > 0) Green else if (d < 0) Red else Color.White

@Composable fun Stat(label: String, value: String, mod: Modifier = Modifier, color: Color = Color.White) {
    Card(mod, colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 12.sp, color = Color.Gray, maxLines = 1)
            Text(value, fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = color, maxLines = 1)
        }
    }
}

@Composable fun Pair2(a: Pair<String, String>, b: Pair<String, String>, ca: Color = Color.White, cb: Color = Color.White) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Stat(a.first, a.second, Modifier.weight(1f), ca); Stat(b.first, b.second, Modifier.weight(1f), cb)
    }
}

fun session(): String {
    val h = ZonedDateTime.now(ZoneId.of("Asia/Jakarta")).hour
    val n = buildList { if (h in 7..15) add("Asia"); if (h in 14..22) add("London"); if (h >= 19 || h < 4) add("New York") }
    return "Session (WIB, approx.): " + n.joinToString(" + ").ifEmpty { "Off-hours" }
}

@Composable fun Dashboard(t: List<Trade>) {
    val s = stats(t)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Ryn", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Cyan)
            Text("Trading Intelligence & Journal", color = Color.Gray)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                Column(Modifier.padding(12.dp)) {
                    Text("Market", fontWeight = FontWeight.SemiBold)
                    Text("Live data unavailable — connect a market data provider.", color = Amber, fontSize = 13.sp)
                    Text(session(), fontSize = 13.sp, color = Color.Gray)
                }
            }
        }
        item { Pair2("Total P&L" to f(s.pnl), "Win rate" to "${f(s.winRate)}%", ca = pnlColor(s.pnl)) }
        item { Pair2("Profit factor" to (if (s.pf.isInfinite()) "∞" else f(s.pf)), "Avg planned RR" to f(s.avgRR)) }
        item { Pair2("Max drawdown" to f(s.maxDD), "Total trades" to "${s.n}", ca = Red) }
        if (t.isEmpty()) item { Text("Your trading journal is empty. Add your first trade in Journal.", color = Color.Gray) }
    }
}

@Composable fun Journal(t: List<Trade>, onSave: (Trade) -> Unit, onDelete: (Trade) -> Unit) {
    var editing by remember { mutableStateOf<Trade?>(null) }
    var adding by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd MMM", Locale.getDefault()) }
    Box(Modifier.fillMaxSize()) {
        if (t.isEmpty()) {
            Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Your trading journal is empty.", color = Color.Gray)
                Button(onClick = { adding = true }) { Text("+ Add First Trade") }
            }
        } else LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(top = 16.dp, bottom = 88.dp)) {
            items(t, key = { it.id }) { x ->
                Card(Modifier.fillMaxWidth().clickable { editing = x },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                    Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text("${x.instrument} ${if (x.isBuy) "BUY" else "SELL"}", fontWeight = FontWeight.SemiBold)
                            Text("${fmt.format(Date(x.date))} · ${x.setup.ifBlank { "—" }}", fontSize = 12.sp, color = Color.Gray, maxLines = 1)
                        }
                        Text((if (x.pnl > 0) "+" else "") + f(x.pnl), color = pnlColor(x.pnl), fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        if (t.isNotEmpty()) FloatingActionButton(onClick = { adding = true }, Modifier.align(Alignment.BottomEnd).padding(16.dp)) {
            Icon(Icons.Filled.Add, "Add trade")
        }
    }
    if (adding) TradeDialog(null, { onSave(it); adding = false }, null) { adding = false }
    editing?.let { e -> TradeDialog(e, { onSave(it); editing = null }, { onDelete(e); editing = null }) { editing = null } }
}

@Composable fun Fld(v: String, label: String, kb: KeyboardType = KeyboardType.Decimal, onC: (String) -> Unit) {
    OutlinedTextField(v, onC, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = kb != KeyboardType.Text || label != "Notes",
        keyboardOptions = KeyboardOptions(keyboardType = kb))
}

@Composable fun TradeDialog(init: Trade?, onSave: (Trade) -> Unit, onDelete: (() -> Unit)?, onDismiss: () -> Unit) {
    var inst by remember { mutableStateOf(init?.instrument ?: "XAUUSD") }
    var buy by remember { mutableStateOf(init?.isBuy ?: true) }
    var entry by remember { mutableStateOf(init?.entry?.toString() ?: "") }
    var sl by remember { mutableStateOf(init?.sl?.toString() ?: "") }
    var tp by remember { mutableStateOf(init?.tp?.toString() ?: "") }
    var risk by remember { mutableStateOf(init?.riskPct?.toString() ?: "1") }
    var pnl by remember { mutableStateOf(init?.pnl?.toString() ?: "") }
    var setup by remember { mutableStateOf(init?.setup ?: "") }
    var emo by remember { mutableStateOf(init?.emotion ?: "Calm") }
    var plan by remember { mutableStateOf(init?.followedPlan ?: true) }
    var notes by remember { mutableStateOf(init?.notes ?: "") }
    AlertDialog(onDismissRequest = onDismiss,
        title = { Text(if (init == null) "New trade" else "Edit trade") },
        confirmButton = {
            TextButton(onClick = {
                onSave(Trade(init?.id ?: 0, init?.date ?: System.currentTimeMillis(), inst.trim().uppercase().ifBlank { "XAUUSD" },
                    buy, entry.num(), sl.num(), tp.num(), risk.num(), pnl.num(), setup.trim(), plan, emo, notes))
            }) { Text("Save") }
        },
        dismissButton = {
            Row {
                onDelete?.let { TextButton(onClick = it) { Text("Delete", color = Red) } }
                TextButton(onClick = onDismiss) { Text("Cancel") }
            }
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Fld(inst, "Instrument", KeyboardType.Text) { inst = it }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(buy, { buy = true }, { Text("BUY") })
                    FilterChip(!buy, { buy = false }, { Text("SELL") })
                }
                Fld(entry, "Entry") { entry = it }; Fld(sl, "Stop loss") { sl = it }; Fld(tp, "Take profit") { tp = it }
                Fld(risk, "Risk %") { risk = it }
                Fld(pnl, "P&L (negative for loss)", KeyboardType.Text) { pnl = it }
                Fld(setup, "Setup (e.g. HTF POI + MSS)", KeyboardType.Text) { setup = it }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Calm", "Fear", "FOMO", "Revenge", "Greed", "Confident", "Impatient").forEach {
                        FilterChip(emo == it, { emo = it }, { Text(it) })
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) { Text("Followed my plan", Modifier.weight(1f)); Switch(plan, { plan = it }) }
                Fld(notes, "Notes", KeyboardType.Text) { notes = it }
                val rr = if (entry.num() != sl.num()) abs(tp.num() - entry.num()) / abs(entry.num() - sl.num()) else 0.0
                val chk = listOf("Risk ≤1%" to (risk.num() > 0 && risk.num() <= 1.0), "RR ≥1:2" to (rr >= 2), "Plan followed" to plan, "Emotion" to (emo == "Calm" || emo == "Confident"))
                Text("Plan compliance: " + chk.joinToString("  ") { (if (it.second) "✓ " else "⚠ ") + it.first }, fontSize = 12.sp, color = Color.Gray)
                if (init != null) Shots(init.id) else Text("Save the trade first to attach Before/During/After screenshots.", fontSize = 12.sp, color = Color.Gray)
            }
        })
}

@Composable fun Analytics(t: List<Trade>) {
    val s = stats(t)
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item { Text("Analytics", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (t.isEmpty()) { item { Text("No trades yet.", color = Color.Gray) }; return@LazyColumn }
        item { Pair2("Trades" to "${s.n}", "Wins / Losses" to "${s.wins} / ${s.n - s.wins}") }
        item { Pair2("Win rate" to "${f(s.winRate)}%", "Expectancy" to f(s.expectancy), cb = pnlColor(s.expectancy)) }
        item { Pair2("Profit factor" to (if (s.pf.isInfinite()) "∞" else f(s.pf)), "Max drawdown" to f(s.maxDD), cb = Red) }
        item {
            Text("Equity curve", color = Color.Gray)
            val c = s.curve
            Canvas(Modifier.fillMaxWidth().height(160.dp)) {
                if (c.size > 1) {
                    val mn = c.min(); val mx = c.max(); val rg = if (mx - mn > 0) mx - mn else 1.0
                    val p = Path()
                    c.forEachIndexed { i, v ->
                        val x = size.width * i / (c.size - 1); val y = (size.height * (1 - (v - mn) / rg)).toFloat()
                        if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
                    }
                    drawPath(p, Cyan, style = Stroke(3f))
                }
            }
        }
        extraItems(t)
        item { Text("P&L by instrument", color = Color.Gray) }
        items(t.groupBy { it.instrument }.map { it.key to it.value.sumOf { x -> x.pnl } }.sortedByDescending { it.second }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(it.first); Text(f(it.second), color = pnlColor(it.second)) }
        }
        item { Text("P&L by setup", color = Color.Gray) }
        items(t.groupBy { it.setup.ifBlank { "—" } }.map { it.key to it.value.sumOf { x -> x.pnl } }.sortedByDescending { it.second }) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(it.first, Modifier.weight(1f), maxLines = 1); Text(f(it.second), color = pnlColor(it.second)) }
        }
    }
}

@Composable fun RiskCalc() {
    var acc by remember { mutableStateOf("10000") }; var risk by remember { mutableStateOf("1") }
    var sl by remember { mutableStateOf("5") }; var cs by remember { mutableStateOf("100") }
    val usd = acc.num() * risk.num() / 100
    val lots = if (sl.num() > 0 && cs.num() > 0) usd / (sl.num() * cs.num()) else 0.0
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Risk calculator", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Fld(acc, "Account size ($)") { acc = it }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf("0.25", "0.5", "1", "2").forEach { FilterChip(risk == it, { risk = it }, { Text("$it%") }) } }
        Fld(risk, "Risk %") { risk = it }
        Fld(sl, "Stop loss distance (price units)") { sl = it }
        Fld(cs, "Contract size per 1.00 lot (XAUUSD = 100)") { cs = it }
        Pair2("Risk $" to f(usd), "Lot size" to "%.3f".format(lots))
        Pair2("Profit @ 1:2" to f(usd * 2), "Profit @ 1:3" to f(usd * 3), ca = Green, cb = Green)
        if (risk.num() > 2) Text("⚠ Risk above 2% per trade is aggressive.", color = Amber)
        Text("Verify contract size and tick value with your broker before trading.", fontSize = 12.sp, color = Color.Gray)
    }
}
