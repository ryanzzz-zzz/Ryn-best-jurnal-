package com.ryn.tradejournal

import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.room.Room
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class RynApp : Application() {
    val db by lazy { Room.databaseBuilder(this, Db::class.java, "ryn.db").build() }
}

class MainVM(app: Application) : AndroidViewModel(app) {
    private val dao = (app as RynApp).db.dao()
    val trades = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    fun save(t: Trade) { viewModelScope.launch { dao.upsert(t) } }
    fun delete(t: Trade) { viewModelScope.launch { dao.delete(t) } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RynTheme { RynRoot() } }
    }
}

@Composable fun RynTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Cyan, background = Color(0xFF0B0F14), surface = Color(0xFF121821),
        onBackground = Color.White, onSurface = Color.White)) {
        Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) { content() }
    }
}

enum class Tab(val label: String, val icon: ImageVector) {
    Dash("Dashboard", Icons.Filled.Dashboard), Journal("Journal", Icons.Filled.Book),
    Replay("Replay", Icons.Filled.PlayArrow), Analytics("Analytics", Icons.Filled.BarChart),
    Tools("More", Icons.Filled.Calculate)
}

@Composable fun RynRoot(vm: MainVM = viewModel()) {
    var splash by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { delay(1200); splash = false }
    if (splash) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Ryn", fontSize = 48.sp, fontWeight = FontWeight.Bold, color = Cyan)
                Text("Trade Journal", fontSize = 18.sp)
                Text("Trade. Review. Improve.", fontSize = 13.sp, color = Color.Gray)
            }
        }
        return
    }
    val trades by vm.trades.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    Scaffold(containerColor = MaterialTheme.colorScheme.background, bottomBar = {
        NavigationBar {
            Tab.values().forEachIndexed { i, t ->
                NavigationBarItem(selected = tab == i, onClick = { tab = i },
                    icon = { Icon(t.icon, null) }, label = { Text(t.label, fontSize = 11.sp, maxLines = 1) })
            }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (Tab.values()[tab]) {
                Tab.Dash -> Dashboard(trades)
                Tab.Journal -> Journal(trades, vm::save, vm::delete)
                Tab.Replay -> ReplayScreen { vm.save(it) }
                Tab.Analytics -> Analytics(trades)
                Tab.Tools -> Hub()
            }
        }
    }
}
