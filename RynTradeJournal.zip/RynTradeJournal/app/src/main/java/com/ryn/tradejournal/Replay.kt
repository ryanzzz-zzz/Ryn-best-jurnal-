package com.ryn.tradejournal

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

data class Pos(val buy: Boolean, val entry: Double, val sl: Double, val tp: Double)

@Composable fun ReplayScreen(onClosed: (Trade) -> Unit) {
    var candles by remember { mutableStateOf(emptyList<Candle>()) }
    var idx by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1f) }
    var pos by remember { mutableStateOf<Pos?>(null) }
    var symbol by remember { mutableStateOf("XAUUSD") }
    var slT by remember { mutableStateOf("") }; var tpT by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val txt = runCatching { ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull().orEmpty()
            candles = parseCsv(txt); idx = minOf(30, candles.size - 1).coerceAtLeast(0); playing = false; pos = null
            msg = if (candles.isEmpty()) "No valid rows found. Expected: time,open,high,low,close" else "${candles.size} candles loaded"
        }
    }
    fun close(p: Pos, exit: Double) {
        val pts = (exit - p.entry) * if (p.buy) 1 else -1
        onClosed(Trade(0, System.currentTimeMillis(), symbol.trim().uppercase(), p.buy, p.entry, p.sl, p.tp, 0.0, pts,
            "Backtest", true, "", "Replay backtest. P&L in price points."))
        msg = "Closed at ${f(exit)} (${f(pts)} pts) — saved to Journal"; pos = null
    }
    fun step() {
        if (idx >= candles.size - 1) { playing = false; return }
        idx++; val c = candles[idx]
        pos?.let { p ->
            val hitSl = if (p.buy) c.l <= p.sl else c.h >= p.sl
            val hitTp = if (p.buy) c.h >= p.tp else c.l <= p.tp
            if (hitSl || hitTp) close(p, if (hitSl) p.sl else p.tp) // SL assumed first if both hit (conservative)
        }
    }
    LaunchedEffect(playing, speed) { while (playing) { delay((1000 / speed).toLong()); step() } }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Market Replay", fontSize = 24.sp)
        if (candles.isEmpty()) {
            Text("No historical data loaded. Import an OHLC CSV (time,open,high,low,close) or connect a MarketDataProvider.", color = Amber, fontSize = 13.sp)
        } else Canvas(Modifier.fillMaxWidth().height(260.dp).background(Color(0xFF0E141B))) {
            val v = candles.subList(maxOf(0, idx - 59), idx + 1)
            val hi = v.maxOf { it.h }; val lo = v.minOf { it.l }; val rg = if (hi - lo > 0) hi - lo else 1.0
            fun y(p: Double) = (size.height * (1 - (p - lo) / rg)).toFloat()
            val w = size.width / 60f
            v.forEachIndexed { i, c ->
                val x = i * w + w / 2; val col = if (c.c >= c.o) Green else Red
                drawLine(col, Offset(x, y(c.h)), Offset(x, y(c.l)), 1.5f)
                val top = y(maxOf(c.o, c.c)); val bot = y(minOf(c.o, c.c))
                drawRect(col, Offset(x - w * 0.35f, top), Size(w * 0.7f, maxOf(1f, bot - top)))
            }
            pos?.let { p -> listOf(p.entry to Cyan, p.sl to Red, p.tp to Green).forEach { (pr, col) ->
                if (pr in lo..hi) drawLine(col, Offset(0f, y(pr)), Offset(size.width, y(pr)), 1.5f) } }
        }
        if (candles.isNotEmpty()) Text("${candles[idx].t}  ·  Close ${f(candles[idx].c)}  ·  ${idx + 1}/${candles.size}", fontSize = 12.sp, color = Color.Gray)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { pick.launch(arrayOf("*/*")) }) { Text("Import CSV") }
            IconButton(onClick = { if (candles.isNotEmpty()) playing = !playing }) { Icon(if (playing) Icons.Filled.Pause else Icons.Filled.PlayArrow, "Play/Pause") }
            IconButton(onClick = { if (candles.isNotEmpty()) step() }) { Icon(Icons.Filled.SkipNext, "Step") }
            TextButton(onClick = { speed = when (speed) { 0.5f -> 1f; 1f -> 2f; 2f -> 5f; else -> 0.5f } }) { Text("${speed}x") }
        }
        if (candles.isNotEmpty()) {
            if (pos == null) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(slT, { slT = it }, Modifier.weight(1f), label = { Text("SL") }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(tpT, { tpT = it }, Modifier.weight(1f), label = { Text("TP") }, singleLine = true, keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = KeyboardType.Decimal))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(true, false).forEach { buy ->
                        Button(onClick = {
                            val e = candles[idx].c; val s = slT.num(); val t = tpT.num()
                            val ok = s > 0 && t > 0 && (if (buy) s < e && t > e else s > e && t < e)
                            if (ok) { pos = Pos(buy, e, s, t); msg = "Opened ${if (buy) "BUY" else "SELL"} @ ${f(e)}" } else msg = "Set valid SL/TP for the direction"
                        }, Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = if (buy) Green else Red)) { Text(if (buy) "BUY" else "SELL") }
                    }
                }
            } else {
                val p = pos!!
                Text("Open ${if (p.buy) "BUY" else "SELL"} @ ${f(p.entry)}  SL ${f(p.sl)}  TP ${f(p.tp)}", fontSize = 13.sp)
                OutlinedButton(onClick = { close(p, candles[idx].c) }) { Text("Close at market") }
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Color.Gray)
    }
}
