package com.ryn.tradejournal

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

fun prefs(c: Context) = c.getSharedPreferences("ryn", Context.MODE_PRIVATE)

// ---- Provider abstractions (plug in paid/real sources here) ----
data class EconEvent(val time: String, val country: String, val name: String, val prev: String, val forecast: String, val actual: String, val impact: String)
data class NewsItem(val headline: String, val source: String, val published: String, val category: String, val importance: String)
interface EconomicCalendarProvider { suspend fun events(fromMs: Long, toMs: Long): List<EconEvent> }
interface NewsProvider { suspend fun news(category: String): List<NewsItem> }

/** Official macro data from FRED. ADD API KEY HERE: put FRED_API_KEY=... in local.properties (never commit it). */
object Fred {
    suspend fun latest(id: String): Result<Pair<String, Double>> = withContext(Dispatchers.IO) {
        runCatching {
            if (BuildConfig.FRED_API_KEY.isBlank()) error("no key")
            val u = URL("https://api.stlouisfed.org/fred/series/observations?series_id=$id&api_key=${BuildConfig.FRED_API_KEY}&file_type=json&sort_order=desc&limit=5")
            val c = u.openConnection() as HttpURLConnection
            c.connectTimeout = 8000; c.readTimeout = 8000
            val arr = JSONObject(c.inputStream.bufferedReader().use { it.readText() }).getJSONArray("observations")
            var out: Pair<String, Double>? = null
            for (i in 0 until arr.length()) {
                val r = arr.getJSONObject(i); val v = r.getString("value").toDoubleOrNull()
                if (v != null) { out = r.getString("date") to v; break }
            }
            out ?: error("no data")
        }
    }
}

val goldSeries = listOf("DGS10" to "US 10Y Treasury yield (%)", "DFII10" to "US 10Y real yield (%)", "DGS2" to "US 2Y Treasury yield (%)",
    "FEDFUNDS" to "Fed funds rate (%)", "UNRATE" to "Unemployment rate (%)", "CPIAUCSL" to "CPI index level (not YoY)",
    "PCEPI" to "PCE price index level", "DTWEXBGS" to "Broad USD index (not DXY)")

@Composable fun GoldScreen() {
    val ctx = LocalContext.current; val p = remember { prefs(ctx) }
    var rows by remember { mutableStateOf(mapOf<String, String>()) }
    var status by remember { mutableStateOf("Loading…") }
    LaunchedEffect(Unit) {
        var offline = false; val m = mutableMapOf<String, String>()
        goldSeries.forEach { (id, _) ->
            val r = Fred.latest(id)
            if (r.isSuccess) { val (d, v) = r.getOrThrow(); p.edit().putString("fred_$id", "$d|$v").apply(); m[id] = "$v ($d)" }
            else { offline = true; p.getString("fred_$id", null)?.let { val s = it.split("|"); m[id] = "${s[1]} (${s[0]}, cached)" } }
        }
        rows = m
        status = if (BuildConfig.FRED_API_KEY.isBlank()) "Connect a data provider: add FRED_API_KEY to local.properties (free key from fred.stlouisfed.org)."
        else if (offline) "Offline — showing cached data"
        else "Source: FRED. Latest published observation, not real-time."
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Gold / XAUUSD intelligence", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("XAUUSD price: live data unavailable — connect a market data provider.", color = Amber, fontSize = 13.sp)
        Text(status, color = Amber, fontSize = 13.sp)
        goldSeries.forEach { (id, label) ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(label, Modifier.weight(1f), fontSize = 13.sp); Text(rows[id] ?: "—", fontSize = 13.sp, color = Cyan)
            }
        }
        Text("Gold drivers", fontWeight = FontWeight.SemiBold)
        listOf("USD stronger → can add bearish pressure on Gold",
            "Real yields higher → can add bearish pressure; lower → can add bullish pressure",
            "Fed hawkish → tends to add bearish pressure; dovish → bullish pressure",
            "Inflation expectations higher → may support Gold, depending on the Fed response",
            "Geopolitical risk higher → may lift safe-haven demand in some conditions")
            .forEach { Text("• $it", fontSize = 13.sp, color = Color.LightGray) }
        Text("These are tendencies, not guarantees. Outcomes depend on market expectations. Not financial advice.", fontSize = 12.sp, color = Color.Gray)
    }
}

@Composable fun ProviderNeeded(title: String, what: String) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("$what unavailable.", color = Color.Gray)
        Text("Connect a data provider to enable live market intelligence. Implement the provider interface in Extras.kt (no fake data is shown).", color = Amber, fontSize = 13.sp)
    }
}

@Composable fun Watchlist() {
    val ctx = LocalContext.current; val p = remember { prefs(ctx) }
    var list by remember { mutableStateOf((p.getString("wl", null) ?: "XAUUSD,EURUSD,GBPUSD,USDJPY,NAS100,US30,BTCUSD,DXY,US10Y").split(",").filter { it.isNotBlank() }) }
    var add by remember { mutableStateOf("") }
    fun save(l: List<String>) { list = l; p.edit().putString("wl", l.joinToString(",")).apply() }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Watchlist", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Live prices unavailable — connect a market data provider.", color = Amber, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(add, { add = it }, Modifier.weight(1f), label = { Text("Add instrument") }, singleLine = true)
            Button(onClick = { val s = add.trim().uppercase(); if (s.isNotEmpty() && s !in list) save(list + s); add = "" }) { Text("Add") }
        }
        LazyColumn { items(list) { s ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(s); TextButton(onClick = { save(list - s) }) { Text("Remove", color = Red) }
            }
        } }
    }
}

@Composable fun PlanScreen() {
    val p = remember { prefs(LocalContext.current) }
    val keys = listOf("Market bias", "Key levels", "HTF POI", "Liquidity", "Important news", "Invalidation", "Preferred setup", "Max trades", "Max risk %")
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Today's plan", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        keys.forEach { k ->
            var v by remember { mutableStateOf(p.getString("plan_$k", "") ?: "") }
            OutlinedTextField(v, { v = it; p.edit().putString("plan_$k", it).apply() }, Modifier.fillMaxWidth(), label = { Text(k) })
        }
    }
}

@Composable fun Checklist() {
    val items = listOf("HTF bias clear", "Valid POI", "Liquidity identified", "Price reached POI", "MSS confirmed", "Entry POI valid",
        "SL defined", "TP defined", "RR ≥ 1:2", "Risk ≤ 1%", "No major news conflict", "Emotion controlled")
    val checked = remember { mutableStateListOf<Int>() }
    var msg by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Pre-trade checklist", fontSize = 24.sp, fontWeight = FontWeight.Bold)
        items.forEachIndexed { i, t ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(i in checked, { if (it) checked.add(i) else checked.remove(i) }); Text(t)
            }
        }
        Button(onClick = {
            val miss = items.size - checked.size
            msg = if (miss == 0) "Checklist complete." else "$miss item(s) unchecked. You can still proceed — this is a reminder, not a block."
        }, Modifier.padding(top = 8.dp)) { Text("CONFIRM TRADE") }
        if (msg.isNotEmpty()) Text(msg, color = if (msg.startsWith("Checklist")) Green else Amber, fontSize = 13.sp)
    }
}

private fun saveShot(ctx: Context, uri: Uri, file: File) {
    runCatching {
        val bytes = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: return
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
        var s = 1; while (o.outWidth / s > 1600) s *= 2
        val bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply { inSampleSize = s }) ?: return
        FileOutputStream(file).use { bm.compress(Bitmap.CompressFormat.JPEG, 80, it) }
    }
}

@Composable fun Shots(id: Long) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }; var slot by remember { mutableStateOf("before") }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) { saveShot(ctx, uri, File(ctx.filesDir, "shot_${id}_$slot.jpg")); ver++ }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("before", "during", "after").forEach { s ->
            val bm = remember(ver) { BitmapFactory.decodeFile(File(ctx.filesDir, "shot_${id}_$s.jpg").path)?.asImageBitmap() }
            Column(Modifier.weight(1f).clickable { slot = s; pick.launch(arrayOf("image/*")) }, horizontalAlignment = Alignment.CenterHorizontally) {
                if (bm != null) Image(bm, s, Modifier.fillMaxWidth().height(80.dp), contentScale = ContentScale.Crop)
                else Box(Modifier.fillMaxWidth().height(80.dp).background(Color(0xFF1A2230)), contentAlignment = Alignment.Center) { Text("+", fontSize = 20.sp) }
                Text(s.replaceFirstChar { it.uppercase() }, fontSize = 11.sp)
            }
        }
    }
}

@Composable fun Hub() {
    val secs = listOf("Risk", "Plan", "Checklist", "Watchlist", "Gold", "Calendar", "News", "About")
    var sec by rememberSaveable { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            secs.forEachIndexed { i, s -> FilterChip(sec == i, { sec = i }, { Text(s) }) }
        }
        Box(Modifier.weight(1f)) {
            when (sec) {
                0 -> RiskCalc(); 1 -> PlanScreen(); 2 -> Checklist(); 3 -> Watchlist(); 4 -> GoldScreen()
                5 -> CalendarScreen()
                6 -> NewsScreen()
                else -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ryn", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = Cyan); Text("Trade Journal · v0.1.0")
                    Text("Trade. Review. Improve.", color = Color.Gray)
                    Text("For journaling and education only. Not financial advice; no trading signals.", fontSize = 12.sp, color = Color.Gray)
                }
            }
        }
    }
}
