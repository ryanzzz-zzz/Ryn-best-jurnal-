package com.ryn.tradejournal

import androidx.room.*
import kotlinx.coroutines.flow.Flow
import kotlin.math.abs

@Entity(tableName = "trades")
data class Trade(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val date: Long, val instrument: String, val isBuy: Boolean,
    val entry: Double, val sl: Double, val tp: Double, val riskPct: Double, val pnl: Double,
    val setup: String, val followedPlan: Boolean, val emotion: String, val notes: String
)

@Dao interface TradeDao {
    @Query("SELECT * FROM trades ORDER BY date DESC") fun all(): Flow<List<Trade>>
    @Upsert suspend fun upsert(t: Trade)
    @Delete suspend fun delete(t: Trade)
}

@Database(entities = [Trade::class], version = 1, exportSchema = false)
abstract class Db : RoomDatabase() { abstract fun dao(): TradeDao }

data class Stats(val n: Int, val wins: Int, val winRate: Double, val pnl: Double, val pf: Double,
                 val avgRR: Double, val maxDD: Double, val expectancy: Double, val curve: List<Double>)

fun stats(t: List<Trade>): Stats {
    val s = t.sortedBy { it.date }
    val gp = s.filter { it.pnl > 0 }.sumOf { it.pnl }
    val gl = -s.filter { it.pnl < 0 }.sumOf { it.pnl }
    var eq = 0.0; var pk = 0.0; var dd = 0.0
    val curve = mutableListOf(0.0)
    s.forEach { eq += it.pnl; curve.add(eq); pk = maxOf(pk, eq); dd = maxOf(dd, pk - eq) }
    val rr = s.mapNotNull { val r = abs(it.entry - it.sl); if (r == 0.0) null else abs(it.tp - it.entry) / r }
    val wins = s.count { it.pnl > 0 }
    val pf = if (gl == 0.0) (if (gp > 0) Double.POSITIVE_INFINITY else 0.0) else gp / gl
    return Stats(s.size, wins, if (s.isEmpty()) 0.0 else wins * 100.0 / s.size, eq, pf,
        if (rr.isEmpty()) 0.0 else rr.average(), dd, if (s.isEmpty()) 0.0 else eq / s.size, curve)
}

/** Plug a real historical OHLC API in here. Nothing is fabricated when no provider is connected. */
data class Candle(val t: String, val o: Double, val h: Double, val l: Double, val c: Double)
interface MarketDataProvider { suspend fun candles(symbol: String, timeframe: String, fromMs: Long, toMs: Long): List<Candle> }

/** CSV format: time,open,high,low,close (header optional). */
fun parseCsv(text: String): List<Candle> = text.lineSequence().mapNotNull { line ->
    val p = line.split(',', ';', '\t').map { it.trim() }
    if (p.size < 5) return@mapNotNull null
    val o = p[1].toDoubleOrNull(); val h = p[2].toDoubleOrNull()
    val l = p[3].toDoubleOrNull(); val c = p[4].toDoubleOrNull()
    if (o == null || h == null || l == null || c == null) null else Candle(p[0], o, h, l, c)
}.toList()
